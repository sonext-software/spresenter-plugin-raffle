// Shared design system for Spresenter plugin UIs.
//
// Every plugin UI runs in its own sandboxed <iframe>, so historically each one
// re-styled its own buttons, inputs and panels from scratch — the result looked
// inconsistent across plugins. This module ships ONE stylesheet (design tokens +
// component classes) that matches the host app's theme, so every plugin that
// uses the kit looks like a native part of Spresenter.
//
// The tokens mirror the app's Tailwind theme (tailwind.config.js):
//   background #12151a · background-secondary #1b1e27 · header #0F1115
//   primary #4834d4 · live/danger #e74c3c · preview/success #2ecc71 · hide/warning #f39c12
//
// Usage:
//   import { injectStyles } from '@spresenter/plugin-sdk/ui-kit';
//   injectStyles(); // once, at UI startup — idempotent
// Then use the `sp-*` classes directly, or the vanilla/React component helpers.

const STYLE_ELEMENT_ID = 'spresenter-ui-kit';

/** The raw CSS of the shared design system. Exposed for advanced/custom setups. */
export const uiKitCss = /* css */ `
:root {
  --sp-bg: #12151a;
  --sp-bg-elevated: #1b1e27;
  --sp-bg-inset: #0f1218;
  --sp-header: #0f1115;
  --sp-surface-hover: #232735;

  --sp-primary: #4834d4;
  --sp-primary-hover: #5a48e0;
  --sp-primary-active: #3d2bbf;

  --sp-success: #2ecc71;
  --sp-danger: #e74c3c;
  --sp-warning: #f39c12;

  --sp-text: #e6e8ec;
  --sp-text-muted: #8a90a0;
  --sp-text-faint: #5c6270;

  --sp-border: #2a2e37;
  --sp-border-strong: #3a3f4b;
  --sp-focus-ring: rgba(72, 52, 212, 0.55);

  --sp-radius-sm: 6px;
  --sp-radius: 8px;
  --sp-radius-lg: 12px;

  --sp-gap-xs: 4px;
  --sp-gap-sm: 8px;
  --sp-gap: 12px;
  --sp-gap-lg: 20px;

  --sp-font: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto,
    Helvetica, Arial, sans-serif;

  color-scheme: dark;
}

/* Reset scoped to plugin UIs. */
.sp-root *,
.sp-root *::before,
.sp-root *::after {
  box-sizing: border-box;
}

/* ---- Root layout ---------------------------------------------------------- */
.sp-root {
  min-height: 100vh;
  margin: 0;
  padding: var(--sp-gap-lg);
  display: flex;
  flex-direction: column;
  gap: var(--sp-gap);
  background: var(--sp-bg);
  color: var(--sp-text);
  font-family: var(--sp-font);
  font-size: 14px;
  line-height: 1.45;
  -webkit-font-smoothing: antialiased;
}

/* ---- Header --------------------------------------------------------------- */
.sp-header {
  display: flex;
  flex-direction: column;
  gap: var(--sp-gap-xs);
}
.sp-header__title {
  margin: 0;
  font-size: 16px;
  font-weight: 600;
  letter-spacing: -0.01em;
}
.sp-header__subtitle {
  margin: 0;
  font-size: 13px;
  color: var(--sp-text-muted);
}

/* ---- Panel (grouped card) ------------------------------------------------- */
.sp-panel {
  display: flex;
  flex-direction: column;
  gap: var(--sp-gap-sm);
  padding: var(--sp-gap);
  border: 1px solid var(--sp-border);
  border-radius: var(--sp-radius-lg);
  background: var(--sp-bg-elevated);
}
.sp-panel__label {
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--sp-text-muted);
}

/* ---- Layout helpers ------------------------------------------------------- */
.sp-row {
  display: flex;
  gap: var(--sp-gap-sm);
  align-items: flex-start;
}
.sp-stack {
  display: flex;
  flex-direction: column;
  gap: var(--sp-gap-sm);
}
.sp-grow { flex: 1; }
.sp-hint {
  font-size: 12px;
  color: var(--sp-text-muted);
}

/* ---- Field (labeled control) --------------------------------------------- */
.sp-field {
  display: flex;
  flex-direction: column;
  gap: var(--sp-gap-xs);
  flex: 1;
  min-width: 0;
}
.sp-field__label {
  font-size: 11px;
  font-weight: 500;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: var(--sp-text-muted);
}
.sp-field__hint {
  font-size: 11px;
  color: var(--sp-text-faint);
}

/* ---- Inputs / textarea / select ------------------------------------------ */
.sp-input,
.sp-textarea,
.sp-select {
  width: 100%;
  padding: 8px 10px;
  font-family: inherit;
  font-size: 13px;
  color: var(--sp-text);
  background: var(--sp-bg-inset);
  border: 1px solid var(--sp-border);
  border-radius: var(--sp-radius);
  outline: none;
  transition: border-color 120ms ease, box-shadow 120ms ease;
}
.sp-input::placeholder,
.sp-textarea::placeholder { color: var(--sp-text-faint); }
.sp-input:focus,
.sp-textarea:focus,
.sp-select:focus {
  border-color: var(--sp-primary);
  box-shadow: 0 0 0 3px var(--sp-focus-ring);
}
.sp-input:disabled,
.sp-textarea:disabled,
.sp-select:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
.sp-textarea { resize: vertical; min-height: 72px; }
.sp-textarea--mono {
  font-family: 'JetBrains Mono', 'SFMono-Regular', Consolas, monospace;
}
.sp-select {
  appearance: none;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%238a90a0' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: right 10px center;
  padding-right: 28px;
}

/* ---- Checkbox ------------------------------------------------------------- */
.sp-checkbox {
  display: inline-flex;
  align-items: center;
  gap: var(--sp-gap-sm);
  font-size: 13px;
  color: var(--sp-text);
  cursor: pointer;
  user-select: none;
}
.sp-checkbox__input {
  appearance: none;
  width: 16px;
  height: 16px;
  flex: none;
  border: 1px solid var(--sp-border-strong);
  border-radius: 4px;
  background: var(--sp-bg-inset);
  cursor: pointer;
  position: relative;
  transition: background 120ms ease, border-color 120ms ease;
}
.sp-checkbox__input:checked {
  background: var(--sp-primary);
  border-color: var(--sp-primary);
}
.sp-checkbox__input:checked::after {
  content: '';
  position: absolute;
  left: 4px;
  top: 1px;
  width: 5px;
  height: 9px;
  border: solid #fff;
  border-width: 0 2px 2px 0;
  transform: rotate(45deg);
}
.sp-checkbox__input:focus-visible {
  box-shadow: 0 0 0 3px var(--sp-focus-ring);
}

/* ---- Buttons -------------------------------------------------------------- */
.sp-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 8px 16px;
  font-family: inherit;
  font-size: 13px;
  font-weight: 500;
  color: var(--sp-text);
  background: var(--sp-surface-hover);
  border: 1px solid var(--sp-border);
  border-radius: var(--sp-radius);
  cursor: pointer;
  white-space: nowrap;
  transition: background 120ms ease, border-color 120ms ease, opacity 120ms ease;
}
.sp-btn:hover:not(:disabled) { background: var(--sp-border-strong); }
.sp-btn:focus-visible { box-shadow: 0 0 0 3px var(--sp-focus-ring); outline: none; }
.sp-btn:disabled { opacity: 0.4; cursor: not-allowed; }

.sp-btn--primary {
  background: var(--sp-primary);
  border-color: var(--sp-primary);
  color: #fff;
}
.sp-btn--primary:hover:not(:disabled) { background: var(--sp-primary-hover); border-color: var(--sp-primary-hover); }

.sp-btn--success {
  background: var(--sp-success);
  border-color: var(--sp-success);
  color: #06371c;
}
.sp-btn--success:hover:not(:disabled) { filter: brightness(1.08); }

.sp-btn--danger {
  background: var(--sp-danger);
  border-color: var(--sp-danger);
  color: #fff;
}
.sp-btn--danger:hover:not(:disabled) { filter: brightness(1.08); }

.sp-btn--ghost {
  background: transparent;
  border-color: var(--sp-border);
}
.sp-btn--ghost:hover:not(:disabled) { background: var(--sp-surface-hover); }

.sp-btn--sm { padding: 5px 10px; font-size: 12px; }
.sp-btn--block { width: 100%; }

/* ---- Actions row ---------------------------------------------------------- */
.sp-actions {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--sp-gap-sm);
}
.sp-actions__spacer { margin-left: auto; }

/* ---- Segmented control (toggle group) ------------------------------------ */
.sp-segmented {
  display: flex;
  gap: var(--sp-gap-sm);
}
.sp-segmented__option {
  flex: 1;
  padding: 7px 12px;
  font-family: inherit;
  font-size: 13px;
  font-weight: 500;
  color: var(--sp-text-muted);
  background: var(--sp-bg-inset);
  border: 1px solid var(--sp-border);
  border-radius: var(--sp-radius);
  cursor: pointer;
  transition: background 120ms ease, color 120ms ease, border-color 120ms ease;
}
.sp-segmented__option:hover:not(.sp-segmented__option--active) {
  background: var(--sp-surface-hover);
  color: var(--sp-text);
}
.sp-segmented__option--active {
  background: var(--sp-primary);
  border-color: var(--sp-primary);
  color: #fff;
}

/* ---- Status indicator ----------------------------------------------------- */
.sp-status {
  display: flex;
  align-items: center;
  gap: var(--sp-gap-sm);
  font-size: 13px;
}
.sp-status__dot {
  width: 9px;
  height: 9px;
  flex: none;
  border-radius: 50%;
  background: var(--sp-text-faint);
}
.sp-status--ok .sp-status__dot { background: var(--sp-success); box-shadow: 0 0 8px var(--sp-success); }
.sp-status--warn .sp-status__dot,
.sp-status--connecting .sp-status__dot { background: var(--sp-warning); }
.sp-status--connecting .sp-status__dot { animation: sp-pulse 1s ease-in-out infinite; }
.sp-status--error .sp-status__dot { background: var(--sp-danger); box-shadow: 0 0 8px var(--sp-danger); }
.sp-status__label { font-weight: 500; }
.sp-status__detail { color: var(--sp-text-muted); font-size: 12px; }

@keyframes sp-pulse { 0%,100% { opacity: 1; } 50% { opacity: 0.35; } }

/* ---- Alert / message ------------------------------------------------------ */
.sp-alert {
  padding: 8px 12px;
  border-radius: var(--sp-radius);
  font-size: 13px;
  border: 1px solid transparent;
}
.sp-alert__detail { margin-top: 4px; font-size: 12px; opacity: 0.8; }
.sp-alert--success { background: rgba(46, 204, 113, 0.12); color: #86e0ad; border-color: rgba(46, 204, 113, 0.3); }
.sp-alert--error { background: rgba(231, 76, 60, 0.12); color: #f0a49b; border-color: rgba(231, 76, 60, 0.3); }
.sp-alert--warning { background: rgba(243, 156, 18, 0.12); color: #f3c078; border-color: rgba(243, 156, 18, 0.3); }
.sp-alert--info { background: rgba(72, 52, 212, 0.14); color: #b3a9f2; border-color: rgba(72, 52, 212, 0.32); }

/* ---- Footer --------------------------------------------------------------- */
.sp-footer {
  margin-top: auto;
  font-size: 12px;
  color: var(--sp-text-faint);
  line-height: 1.6;
}
`;

/**
 * Inject the shared design-system stylesheet into the document <head>.
 * Idempotent — safe to call more than once (e.g. React StrictMode double-mount).
 */
export function injectStyles(doc: Document = document): void {
  if (doc.getElementById(STYLE_ELEMENT_ID)) return;
  const style = doc.createElement('style');
  style.id = STYLE_ELEMENT_ID;
  style.textContent = uiKitCss;
  doc.head.appendChild(style);
}
