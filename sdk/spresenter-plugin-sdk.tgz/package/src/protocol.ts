// Public message protocol for Spresenter plugins (shared contract between the
// plugin UI and the host). Kept in sync with src/main/plugins/types.ts.

export const SPRESENTER_MARKER = '__spresenter' as const;

/** Envelope posted by the UI to the host (and back) via window.postMessage. */
export interface UiEnvelope {
  __spresenter: true;
  data: unknown;
}

export function isUiEnvelope(v: unknown): v is UiEnvelope {
  return !!v && typeof v === 'object' && (v as any).__spresenter === true;
}
